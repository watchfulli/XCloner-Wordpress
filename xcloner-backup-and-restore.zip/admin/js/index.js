 //Third-party Modules
require('./materialize.min.js');

//XCloner Modules
require('./xcloner-admin');
require('./xcloner-backup-class');
require('./xcloner-manage-backups-class');
require('./xcloner-remote-storage-class');
require('./xcloner-restore-class');
require('./xcloner-scheduler-class');